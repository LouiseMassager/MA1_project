from mujoco_simulation import MujocoSimulation


sim=MujocoSimulation()

sim.display_info()
sim.random_mvt()
